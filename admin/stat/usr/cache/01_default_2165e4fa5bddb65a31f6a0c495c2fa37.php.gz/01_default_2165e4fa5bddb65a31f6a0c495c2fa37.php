<?php
//This is a temporary file which has been automatically created by CrazyStat. You can delete it. Then CrazyStat will be slower the next time (and recreate the file).

$pos=0;
$logdatei_name='../usr/logs/stat0.log';
$hits_user_tag=NULL;
$ips=NULL;
$ips_dateien=NULL;
$ips_online=NULL;
$log_file_number=0;
$save_timestamp=1319768084;
$usr_on_stamp=NULL;
$_SESSION["module_keyword_orig"]=NULL;
$_SESSION["module_hit_data"]=array (
  'gesamt' => 0,
  'gesamt_ip' => 0,
  'diesen_monat' => 0,
  'letzten_monat' => 0,
  'user_online' => 0,
  'max' => 0,
  'proUser' => '0',
);
$_SESSION["module_hit_data_timestamps"]=array (
);
$_SESSION["module_weekday_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
);
$_SESSION["module_weekday_data_timestamps"]=array (
);
$_SESSION["module_month_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
);
$_SESSION["module_month_data_timestamps"]=array (
);
$_SESSION["module_day_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 0,
  17 => 0,
  18 => 0,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 0,
  23 => 0,
  24 => 0,
  25 => 0,
  26 => 0,
  27 => 0,
  28 => 0,
  29 => 0,
  30 => 0,
);
$_SESSION["module_day_data_timestamps"]=array (
);
$_SESSION["module_hour_data"]=array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 0,
  17 => 0,
  18 => 0,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 0,
  23 => 0,
);
$_SESSION["module_hour_data_timestamps"]=array (
);
$_SESSION["module_browser_data"]=array (
);
$_SESSION["module_browser_data_timestamps"]=array (
);
$_SESSION["module_file_data"]=array (
);
$_SESSION["module_file_data_timestamps"]=array (
);
$_SESSION["module_resolution_data"]=array (
);
$_SESSION["module_resolution_data_timestamps"]=array (
);
$_SESSION["module_colordepth_data"]=array (
);
$_SESSION["module_colordepth_data_timestamps"]=array (
);
$_SESSION["module_system_data"]=array (
);
$_SESSION["module_system_data_timestamps"]=array (
);
$_SESSION["module_referer_data"]=array (
);
$_SESSION["module_referer_data_timestamps"]=array (
);
$_SESSION["module_keyword_data"]=array (
);
$_SESSION["module_keyword_data_timestamps"]=array (
);
?>